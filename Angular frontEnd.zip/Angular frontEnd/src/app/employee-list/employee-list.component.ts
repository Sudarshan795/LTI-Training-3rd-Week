import { Component, OnInit } from '@angular/core';
import { Producer } from '../producer'
import { ProducerService } from '../producer.service'
import { Router } from '@angular/router';
@Component({
  selector: 'app-employee-list',
  templateUrl: './employee-list.component.html',
  styleUrls: ['./employee-list.component.css']
})
export class ProducerListComponent implements OnInit {

  producer?: Producer[];

  constructor(private producerService: ProducerService,
    private router: Router) { }

  ngOnInit(): void {
    this.getProducer();
  }

  private getAllProducer(){
    this.producerService.getProducersList().subscribe(data => {
      this.producer = data;
    });
  }

  producerDetails(id: number){
    this.router.navigate(['producer-details', id]);
  }

  updateproducer(id: number){
    this.router.navigate(['update-producer', id]);
  }

  deleteproducer(id: number){
    this.producerService.deleteproducer(id).subscribe( data => {
      console.log(data);
      this.getProducer();
    })
  }
}