import { Producer } from './producer';

describe('Producer', () => {
  it('should create an instance', () => {
    expect(new Producer()).toBeTruthy();
  });
});
