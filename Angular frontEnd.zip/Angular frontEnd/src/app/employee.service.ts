import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http'
import { Observable } from 'rxjs';
import { Producer } from './employee';

@Injectable({
  providedIn: 'root'
})
export class producerService {

  private consumerURL = "http://localhost:8091/fetchProducer";
  private producerURL = "http://localhost:8092/api/v1/producer";
  
  constructor(private httpClient: HttpClient) { }
  
  getProducerList(): Observable<Producer[]>{
    return this.httpClient.get<Producer[]>(`${this.consumerURL}`);  
  }

  createProducer(producer: Producer): Observable<Object>{
    return this.httpClient.post(`${this.producerURL}`, producer);
  }

  getProducerById(id: number): Observable<Producer>{
    return this.httpClient.get<Producer>(`${this.producerURL}/${id}`);
  }

  updateProducer(id: number, employee: Producer): Observable<Object>{
    return this.httpClient.put(`${this.producerURL}/${id}`, Producer);
  }

  deleteProducer(id: number): Observable<Object>{
    return this.httpClient.delete(`${this.producerURL}/${id}`);
  }
}
