import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdateProducerComponent } from './producer-employee.component';

describe('UpdateEmployeeComponent', () => {
  let component: UpdateProducerComponent;
  let fixture: ComponentFixture<UpdateProducerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UpdateProducerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UpdateProducerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
