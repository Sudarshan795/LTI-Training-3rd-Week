import { Component, OnInit } from '@angular/core';
import { ProducerService } from '../producer.service';
import { Producer } from '../producer';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-update-producer',
  templateUrl: './update-producer.component.html',
  styleUrls: ['./update-producer.component.css']
})
export class UpdateProducerComponent implements OnInit {

  id!: number;
  producer: Producer = new Producer();
  constructor(private producerService: ProducerService,
    private route: ActivatedRoute,
    private router: Router) { }

  ngOnInit(): void {
    this.id = this.route.snapshot.params['id'];

    this.producerService.getProducerById(this.id).subscribe(data => {
      this.producer = data;
    }, error => console.log(error));
  }

  onSubmit(){
    this.producerService.updateProducer(this.id, this.producer).subscribe( data =>{
      this.goToProducerList();
    }
    , error => console.log(error));
  }

  goToProducerList(){
    this.router.navigate(['/producer']);
  }
}
