import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http'
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ProducerListComponent } from './producer-list/producer-list.component';
import { CreateProducerComponent } from './create-producer/create-producer.component';
import { FormsModule} from '@angular/forms';
import { UpdateProducerComponent } from './update-producer/update-producer.component';
import { ProducerDetailsComponent } from './producer-details/producer-details.component'

@NgModule({
  declarations: [
    AppComponent,
    ProducerListComponent,
    CreateProducerComponent,
    UpdateProducerComponent,
    ProducerDetailsComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
