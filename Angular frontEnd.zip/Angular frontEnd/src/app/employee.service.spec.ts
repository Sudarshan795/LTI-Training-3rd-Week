import { TestBed } from '@angular/core/testing';

import { ProducerService } from './producer.service';

describe('ProducerService', () => {
  let service: producerService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(producerService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
