export class Producer {
    id?: any;
    name?: string;
    age?: string;
    address?: string;
}
