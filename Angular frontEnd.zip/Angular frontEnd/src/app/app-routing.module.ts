import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ProducerListComponent } from './employee-list/producer-list.component';
import { CreateProducerComponent } from './create-producer/create-producer.component';
import { UpdateProducerComponent } from './update-producer/update-producer.component';
import { ProducerDetailsComponent } from './producer-details/producer-details.component';

const routes: Routes = [
  {path: 'producer', component: ProducerListComponent},
  {path: 'create-producer', component: CreateProducerComponent},
  {path: '', redirectTo: 'producer', pathMatch: 'full'},
  {path: 'update-producer/:id', component: UpdateProducerComponent},
  {path: 'producer-details/:id', component: ProducerDetailsComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],                                                                                                                                                                                                                                                                                                          
  exports: [RouterModule]
})
export class AppRoutingModule { }
