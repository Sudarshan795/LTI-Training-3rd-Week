import { Component, OnInit } from '@angular/core';
import { Producer } from '../producer';
import { ActivatedRoute } from '@angular/router';
import { ProducerService } from '../producer.service';

@Component({
  selector: 'app-producer-details',
  templateUrl: './producer-details.component.html',
  styleUrls: ['./producer-details.component.css']
})
export class producerDetailsComponent implements OnInit {

  id!: number;
  producer!: Producer;
  constructor(private route: ActivatedRoute, private producerService: producerService) { }

  ngOnInit(): void {
    this.id = this.route.snapshot.params['id'];

    this.producer = new Producer();
    this.producerService.getproducerById(this.id).subscribe( data => {
      this.producer = data;
    });
  }

}
