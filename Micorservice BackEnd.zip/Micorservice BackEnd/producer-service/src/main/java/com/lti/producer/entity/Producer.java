package com.lti.producer.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
public class Producer {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int producerId;
	@Column(name = "name", nullable = false)
	private String name;
	@Column(name = "age", nullable = false)
	private int age;
	@Column(name = "address", nullable = false)
	private String address;
	@Column(name = "type_of_account", nullable = false)
	private String typeOfAccount;
	
	public Producer() {
		super();
		this.producerId = producerId;
		this.name = name;
		this.age = age;
		this.address = address;
		this.typeOfAccount = typeOfAccount;
	}

	public int getProducerId() {
		return producerId;
	}

	public void setProducerId(int producerId) {
		this.producerId = producerId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getTypeOfAccount() {
		return typeOfAccount;
	}

	public void setTypeOfAccount(String typeOfAccount) {
		this.typeOfAccount = typeOfAccount;
	}

	@Override
	public String toString() {
		return "Producer [producerId=" + producerId + ", name=" + name + ", age=" + age + ", address=" + address
				+ ", typeOfAccount=" + typeOfAccount + "]";
	}

	public static Object add(Producer e) {
		// TODO Auto-generated method stub
		return null;
	}
	
	
}
	