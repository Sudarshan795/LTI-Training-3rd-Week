package com.lti.consumer.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.lti.consumer.entity.Consumer;

@Repository
public interface ConsumerRepsitory extends JpaRepository<Consumer, Long> {

	Consumer findByConsumerId(Long consumerId);

}
