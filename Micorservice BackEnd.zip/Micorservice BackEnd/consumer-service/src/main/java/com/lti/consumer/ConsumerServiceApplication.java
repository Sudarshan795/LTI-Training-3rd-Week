package com.lti.consumer;

import java.io.IOException;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.cloud.netflix.hystrix.EnableHystrix;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;
import com.lti.consumer.controller.ConsumerController;

@SpringBootApplication
@EnableDiscoveryClient
@EnableHystrix
public class ConsumerServiceApplication {

	public static void main(String[] args) throws RestClientException, IOException {
		ApplicationContext ctx = SpringApplication.run(ConsumerServiceApplication.class, args);

		ConsumerController consumerController = ctx.getBean(ConsumerController.class);
		System.out.println(consumerController);
		consumerController.getConsumerFromProducer();
	}

	@Bean
	public ConsumerController consumerControllerClient() {
		return new ConsumerController();
	}

	@Bean
	public RestTemplate restTemplate() {
		return new RestTemplate();
	}

}
