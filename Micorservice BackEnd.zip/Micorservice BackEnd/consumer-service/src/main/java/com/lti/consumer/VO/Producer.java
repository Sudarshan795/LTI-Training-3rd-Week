package com.lti.consumer.VO;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Producer {
	
	private Long producerId;
	private String name;
	private Long age;
	private String address;
	private String typeOfAccount;
	
	public Producer(Long producerId, String name, Long age, String address, String typeOfAccount) {
		super();
		this.producerId = producerId;
		this.name = name;
		this.age = age;
		this.address = address;
		this.typeOfAccount = typeOfAccount;
	}
	public Long getProducerId() {
		return producerId;
	}
	public void setProducerId(Long producerId) {
		this.producerId = producerId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Long getAge() {
		return age;
	}
	public void setAge(Long age) {
		this.age = age;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getTypeOfAccount() {
		return typeOfAccount;
	}
	public void setTypeOfAccount(String typeOfAccount) {
		this.typeOfAccount = typeOfAccount;
	}
	@Override
	public String toString() {
		return "Producer [producerId=" + producerId + ", name=" + name + ", age=" + age + ", address=" + address
				+ ", typeOfAccount=" + typeOfAccount + "]";
	}
	
	
}
